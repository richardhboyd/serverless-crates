time
====

Utilities for working with time-related functions in Rust

[![Build Status](https://travis-ci.org/rust-lang/time.svg?branch=master)](https://travis-ci.org/rust-lang/time)
